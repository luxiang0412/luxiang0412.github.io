#! /bin/sh 
# Failover command for streaming replication. 
# Arguments: $1: new master hostname. 

new_master=$1 
trigger_command="/usr/pgsql-9.4/bin/pg_ctl promote -D /var/lib/pgsql/9.4/data" 

# Prompte standby database. 
echo "new_master:$new_master" > /tmp/new_master
/usr/bin/ssh -T -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null postgres@$new_master -i ~/.ssh/id_rsa $trigger_command

exit 0; 
